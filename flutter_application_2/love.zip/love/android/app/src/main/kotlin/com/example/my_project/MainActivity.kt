package com.mycompany.love

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
